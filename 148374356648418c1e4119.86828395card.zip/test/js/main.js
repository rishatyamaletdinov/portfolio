
   const cards = document.querySelectorAll('.card');
   const fade = document.querySelector('.fade');
   
   cards.forEach(function(item) {
      const btnOpen = item.querySelector('.card__btn');
      const btnClose = item.querySelector('.close');
      
      btnOpen.addEventListener('click', function() {

         cards.forEach((item)=>{

            item.classList.remove('active');

         })
         
         btnOpen.closest('.card').classList.add('active');

         fade.classList.add('active');
         
      });

      btnClose.addEventListener('click',(e)=>{

         e.target.closest('.card').classList.remove('active');
         fade.classList.remove('active');

      })

   });
